// src/app/admin/login/page.tsx
import AdminLogin from "@/components/admin/admin-login"

export default function AdminLoginPage() {
  return <AdminLogin />
}